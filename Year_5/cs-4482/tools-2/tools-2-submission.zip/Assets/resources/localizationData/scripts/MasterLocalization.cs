using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName = "Master Localization", menuName = "Custom/Master Localization")]
public class MasterLocalization : ScriptableObject
{
    public List<string> translationKeys;
    public List<LanguageTranslation> languageTranslations;

    public LanguageTranslation GetLanguageTranslation(string languageName)
    {
        return languageTranslations.Find(language => language.GetLanguage() == languageName);
    }

    public string GetLanguageTranslationValue(string languageName, string key)
    {
        LanguageTranslation language = GetLanguageTranslation(languageName);
        if (language == null)
        {
            Debug.Log("Why language is null");
        }
        Translation translation = language.GetTranslationWithKey(key);
        if (translation == null)
        {
            Debug.Log("Why no translation :(");
            return "";
        }
        return translation.translationValue;
    }
    
    public void DeleteTranslationKey(string key)
    {
        translationKeys.Remove(key);
        foreach (LanguageTranslation languageTranslation in languageTranslations)
        {
            languageTranslation.DeleteKeyTranslation(key);
        }
    }
    
    public void DeleteLanguage(LanguageTranslation languageTranslation)
    {
        languageTranslations.Remove(languageTranslation);
        string pathToDelete = AssetDatabase.GetAssetPath(languageTranslation);
        if (!string.IsNullOrEmpty(pathToDelete))
        {
            AssetDatabase.DeleteAsset(pathToDelete);
        }
    }
}
